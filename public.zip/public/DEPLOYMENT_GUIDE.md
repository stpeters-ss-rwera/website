# ST. PETER'S SECONDARY SCHOOL – RWERA
## Complete Deployment Guide

---

## STEP 1: Create a Supabase Project

1. Go to [https://supabase.com](https://supabase.com)
2. Click **"Start your project"**
3. Sign in with GitHub or Google
4. Click **"New project"**
5. Fill in:
   - **Organization**: Your org
   - **Project Name**: `stpeters-ss-rwera`
   - **Database Password**: Choose a strong password (save it!)
   - **Region**: `Africa (Cape Town)` or nearest region
6. Click **"Create new project"**
7. Wait 2-3 minutes for setup

---

## STEP 2: Set Up Database Tables

1. In Supabase Dashboard, click **"SQL Editor"**
2. Click **"New query"**
3. Copy the entire content from `SUPABASE_SCHEMA.sql`
4. Paste into the editor
5. Click **"Run"**
6. Verify tables are created in **"Table Editor"**

---

## STEP 3: Configure Row Level Security

The SQL script already creates RLS policies. Verify:

1. Go to **Authentication > Policies**
2. Confirm policies exist for all tables
3. Public SELECT policies allow anyone to read
4. Authenticated INSERT/UPDATE/DELETE policies restrict writes

---

## STEP 4: Create Storage Buckets

1. In Supabase Dashboard, click **"Storage"**
2. Click **"New bucket"**
3. Create **Bucket 1**:
   - Name: `school-logo`
   - Public bucket: ✅ YES
   - Click "Create bucket"
4. Create **Bucket 2**:
   - Name: `school-images`
   - Public bucket: ✅ YES
   - Click "Create bucket"

### Set Storage Policies:

For `school-logo` bucket:
- Click on the bucket → "Policies" → "New Policy"
- Allow SELECT for everyone (anon)
- Allow INSERT, UPDATE, DELETE for authenticated users

For `school-images` bucket:
- Same policies as above

---

## STEP 5: Configure Authentication

1. Go to **Authentication > Settings**
2. Under **"Email Auth"**:
   - Enable email confirmations (optional for admin)
3. Go to **Authentication > Users**
4. Click **"Add user"**
5. Enter admin email and strong password
6. Save

---

## STEP 6: Get Your API Keys

1. Go to **Settings > API** in Supabase
2. Copy:
   - **Project URL**: `https://xxxxxxxxxxxx.supabase.co`
   - **Anon Public Key**: `eyJhbGciOiJIUzI1Ni...`
3. Save these values

---

## STEP 7: Configure Environment Variables

Create a `.env` file in your project root:

```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key-here
```

**NEVER commit the `.env` file to GitHub!**

Add `.env` to your `.gitignore`:
```
.env
.env.local
```

For GitHub Pages, use repository secrets:
1. Go to your GitHub repository
2. Settings → Secrets and variables → Actions
3. Add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

---

## STEP 8: Upload to GitHub

1. Create a new GitHub repository
2. Name it: `stpeters-ss-rwera` (or your preferred name)
3. Initialize with README
4. In your local project folder:

```bash
git init
git add .
git commit -m "Initial commit: St. Peter's SS Rwera website"
git branch -M main
git remote add origin https://github.com/yourusername/stpeters-ss-rwera.git
git push -u origin main
```

---

## STEP 9: Enable GitHub Pages with GitHub Actions

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          
      - name: Install dependencies
        run: npm install
        
      - name: Build
        run: npm run build
        env:
          VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: ${{ secrets.VITE_SUPABASE_ANON_KEY }}
          
      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

Then:
1. Push this file to GitHub
2. Go to repository **Settings → Pages**
3. Source: **"GitHub Actions"**
4. Wait for the action to complete

---

## STEP 10: Go Live!

Your website will be available at:
```
https://yourusername.github.io/stpeters-ss-rwera/
```

Or configure a custom domain:
1. Purchase a domain (e.g., stpetersrwera.ac.ug)
2. In GitHub Pages settings, add your custom domain
3. Configure DNS: Add CNAME record pointing to `yourusername.github.io`

---

## ADMIN ACCESS

After deployment:
1. Visit: `https://your-site.github.io/admin`
2. Login with your Supabase admin credentials
3. Manage all content through the dashboard

**Admin Dashboard Features:**
- 📸 School Logo Management
- 🎠 Hero Slider Management  
- 👨‍🏫 Teachers CRUD
- ⭐ Prefects CRUD
- 🖼️ Gallery Management
- 📰 Articles Management
- 📢 Announcements Management
- ⚙️ School Settings

---

## IMPORTANT SECURITY NOTES

1. ✅ Never expose your Supabase SERVICE ROLE key (only use ANON key)
2. ✅ Always use RLS policies
3. ✅ Use environment variables for all secrets
4. ✅ Enable strong passwords for admin accounts
5. ✅ Regularly update dependencies
6. ✅ Monitor Supabase usage in the dashboard

---

## SUPPORT

- School Email: stpetersssrwera2019@gmail.com
- Head Teacher: +256 782 854642
- WhatsApp: +256776747621

*St. Peter's Secondary School – Rwera | Invest in Education*
