import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useInView } from 'react-intersection-observer';
import {
  FaArrowRight, FaGraduationCap, FaUsers, FaTrophy, FaBook,
  FaChevronLeft, FaChevronRight, FaBullhorn, FaWhatsapp,
  FaNewspaper, FaCalendarAlt, FaFlask, FaChurch
} from 'react-icons/fa';
import { HERO_SLIDES, SCHOOL_INFO, SAMPLE_ANNOUNCEMENTS, SAMPLE_ARTICLES } from '../lib/constants';
import { format } from 'date-fns';

// Animated counter
const Counter: React.FC<{ end: number; suffix?: string }> = ({ end, suffix = '' }) => {
  const [count, setCount] = useState(0);
  const { ref, inView } = useInView({ triggerOnce: true });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const increment = end / 120;
    const timer = setInterval(() => {
      start += increment;
      if (start >= end) { setCount(end); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 1000 / 60);
    return () => clearInterval(timer);
  }, [inView, end]);

  return <span ref={ref}>{count}{suffix}</span>;
};

// Reveal on scroll
const Reveal: React.FC<{ children: React.ReactNode; className?: string; delay?: string }> = ({
  children, className = '', delay = ''
}) => {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });
  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ${delay} ${className} ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
    >
      {children}
    </div>
  );
};

const Home: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const sliderRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goToSlide = (index: number) => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrentSlide(index);
    setTimeout(() => setIsTransitioning(false), 1000);
  };

  const nextSlide = () => goToSlide((currentSlide + 1) % HERO_SLIDES.length);
  const prevSlide = () => goToSlide((currentSlide - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);

  useEffect(() => {
    sliderRef.current = setInterval(nextSlide, 5500);
    return () => { if (sliderRef.current) clearInterval(sliderRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentSlide]);

  const stats = [
    { icon: FaUsers, value: 800, suffix: '+', label: 'Students Enrolled', color: 'bg-blue-500' },
    { icon: FaGraduationCap, value: 45, suffix: '+', label: 'Qualified Teachers', color: 'bg-yellow-500' },
    { icon: FaTrophy, value: 15, suffix: '+', label: 'Years of Excellence', color: 'bg-green-600' },
    { icon: FaBook, value: 95, suffix: '%', label: 'Pass Rate', color: 'bg-purple-600' },
  ];

  const highlights = [
    { icon: FaGraduationCap, title: 'Academic Excellence', desc: 'Consistently producing top UCE and UACE performers in Ntungamo District.', colorBg: 'bg-blue-50', colorText: 'text-blue-900' },
    { icon: FaFlask, title: 'Science & Technology', desc: 'Well-equipped science laboratories fostering innovation and discovery.', colorBg: 'bg-yellow-50', colorText: 'text-yellow-800' },
    { icon: FaChurch, title: 'Spiritual Development', desc: 'Guided by Christian values, nurturing students of strong moral character.', colorBg: 'bg-green-50', colorText: 'text-green-800' },
    { icon: FaTrophy, title: 'Sports & Co-curricular', desc: 'Vibrant sports programs and clubs for holistic student development.', colorBg: 'bg-purple-50', colorText: 'text-purple-800' },
  ];

  return (
    <div className="overflow-x-hidden">
      {/* HERO SLIDER */}
      <section className="relative h-[85vh] min-h-[520px] overflow-hidden">
        {HERO_SLIDES.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-all duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100 scale-100' : 'opacity-0 scale-105'}`}
          >
            <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" loading={index === 0 ? 'eager' : 'lazy'} />
            <div className="hero-overlay absolute inset-0" />
          </div>
        ))}

        <div className="relative z-10 h-full flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <div className="flex items-center gap-4 mb-6 animate-fade-in-up">
                <div className="w-16 h-16 md:w-20 md:h-20 bg-white rounded-full p-1.5 shadow-2xl flex-shrink-0">
                  <img src="/logo.png" alt="School Logo" className="w-full h-full object-contain"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                </div>
                <div>
                  <div className="text-yellow-400 text-xs md:text-sm font-bold uppercase tracking-widest">ST. PETER'S SECONDARY SCHOOL</div>
                  <div className="text-white text-2xl md:text-3xl font-bold">– RWERA –</div>
                </div>
              </div>

              <h1 key={currentSlide + 't'} className="text-3xl md:text-5xl lg:text-6xl font-bold text-white text-shadow-lg mb-4 leading-tight animate-fade-in-up delay-200">
                {HERO_SLIDES[currentSlide].title}
              </h1>

              <p key={currentSlide + 's'} className="text-white/90 text-lg md:text-xl mb-8 leading-relaxed text-shadow animate-fade-in-up delay-300">
                {HERO_SLIDES[currentSlide].subtitle}
              </p>

              <div className="flex flex-wrap gap-4 animate-fade-in-up delay-400">
                <Link to="/about" className="btn-secondary text-base px-7 py-3.5">
                  Discover Our School <FaArrowRight />
                </Link>
                <Link to="/contact" className="bg-white/20 backdrop-blur-sm border border-white/40 text-white px-7 py-3.5 rounded-lg font-semibold hover:bg-white/30 transition-all duration-300 flex items-center gap-2 text-base">
                  Contact Us <FaArrowRight />
                </Link>
              </div>
            </div>
          </div>
        </div>

        <button onClick={prevSlide} className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 md:w-12 md:h-12 bg-white/20 hover:bg-white/40 backdrop-blur-sm rounded-full flex items-center justify-center text-white transition-all duration-300 hover:scale-110">
          <FaChevronLeft />
        </button>
        <button onClick={nextSlide} className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 md:w-12 md:h-12 bg-white/20 hover:bg-white/40 backdrop-blur-sm rounded-full flex items-center justify-center text-white transition-all duration-300 hover:scale-110">
          <FaChevronRight />
        </button>

        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex gap-2">
          {HERO_SLIDES.map((_, i) => (
            <button key={i} onClick={() => goToSlide(i)} className={`slider-dot ${i === currentSlide ? 'active' : ''}`} aria-label={`Go to slide ${i + 1}`} />
          ))}
        </div>
      </section>

      {/* STATS */}
      <section className="bg-blue-900 py-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-white rounded-full translate-y-1/2 -translate-x-1/2" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <Reveal key={i} delay={`delay-${(i + 1) * 100}`} className="text-center text-white group">
                <div className={`w-14 h-14 ${stat.color} rounded-2xl mx-auto mb-3 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <stat.icon size={24} className="text-white" />
                </div>
                <div className="stat-number text-white mb-1">
                  <Counter end={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-blue-200 text-sm font-medium">{stat.label}</div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* WELCOME */}
      <section className="py-16 md:py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <Reveal>
              <span className="inline-block bg-yellow-100 text-yellow-800 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">Welcome</span>
              <h2 className="section-title mb-6">Excellence in Education at St. Peter's SS Rwera</h2>
              <p className="text-gray-600 leading-relaxed mb-4">
                Welcome to St. Peter's Secondary School – Rwera, a beacon of academic excellence in Ntungamo District, Uganda. Founded with the vision of providing quality education to the youth of Rwera and surrounding communities, we have grown into a respected institution known for producing well-rounded, disciplined graduates.
              </p>
              <p className="text-gray-600 leading-relaxed mb-6">
                Our school embraces the motto <strong className="text-blue-900">"Invest in Education"</strong> — a guiding principle that drives everything we do, from our rigorous academic programs to our vibrant co-curricular activities.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/about" className="btn-primary">Learn More <FaArrowRight /></Link>
                <a href={SCHOOL_INFO.whatsappGroupLink} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white px-5 py-2.5 rounded-lg font-semibold transition-all duration-300 text-sm">
                  <FaWhatsapp size={16} /> Join Parents Group
                </a>
              </div>
            </Reveal>

            <Reveal delay="delay-200" className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img src="https://images.pexels.com/photos/34162713/pexels-photo-34162713.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700"
                  alt="Students at St. Peter's SS Rwera" className="w-full h-80 md:h-96 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/60 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl p-4 shadow-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center flex-shrink-0">
                        <FaGraduationCap className="text-blue-900" />
                      </div>
                      <div>
                        <div className="font-bold text-blue-900 text-sm">Quality Education Since 2019</div>
                        <div className="text-gray-600 text-xs">Kakukuru-Rwenanura, Ntungamo, Uganda</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-yellow-400 rounded-2xl -z-10 opacity-60" />
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-blue-200 rounded-full -z-10 opacity-60" />
            </Reveal>
          </div>
        </div>
      </section>

      {/* HIGHLIGHTS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <Reveal className="text-center mb-12">
            <span className="inline-block bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-3">Why Choose Us</span>
            <h2 className="section-title">School Highlights</h2>
            <p className="section-subtitle">Discover what makes St. Peter's SS Rwera the preferred choice for quality education</p>
          </Reveal>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {highlights.map((h, i) => (
              <Reveal key={i} delay={`delay-${i * 100}`}>
                <div className={`${h.colorBg} ${h.colorText} rounded-2xl p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-2 group h-full`}>
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center mb-4 shadow-md group-hover:scale-110 transition-transform duration-300">
                    <h.icon size={22} />
                  </div>
                  <h3 className="font-bold text-lg mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>{h.title}</h3>
                  <p className="text-sm leading-relaxed opacity-80">{h.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ANNOUNCEMENTS & ARTICLES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <Reveal>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-red-500 rounded-xl flex items-center justify-center">
                    <FaBullhorn size={18} className="text-white" />
                  </div>
                  <h2 className="text-2xl font-bold text-blue-900" style={{ fontFamily: 'Playfair Display, serif' }}>Announcements</h2>
                </div>
                <div className="space-y-4">
                  {SAMPLE_ANNOUNCEMENTS.map((ann) => (
                    <div key={ann.id} className="bg-gray-50 hover:bg-blue-50 border border-gray-100 hover:border-blue-200 rounded-xl p-4 transition-all duration-300 group">
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0 group-hover:bg-blue-500 transition-colors" />
                        <div>
                          <h4 className="font-semibold text-blue-900 text-sm mb-1 leading-tight">{ann.title}</h4>
                          <p className="text-gray-600 text-xs leading-relaxed line-clamp-2">{ann.content}</p>
                          <div className="flex items-center gap-1 text-gray-400 text-xs mt-2">
                            <FaCalendarAlt size={9} />
                            <span>{format(new Date(ann.created_at), 'MMM d, yyyy')}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Reveal>
            </div>

            <div className="lg:col-span-2">
              <Reveal delay="delay-100">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-900 rounded-xl flex items-center justify-center">
                      <FaNewspaper size={18} className="text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-blue-900" style={{ fontFamily: 'Playfair Display, serif' }}>Latest Articles</h2>
                  </div>
                  <Link to="/articles" className="text-blue-600 hover:text-blue-900 text-sm font-semibold flex items-center gap-1">View All <FaArrowRight size={10} /></Link>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  {SAMPLE_ARTICLES.slice(0, 2).map((article) => (
                    <Link key={article.id} to={`/articles/${article.id}`} className="card group overflow-hidden hover:-translate-y-1 transition-all duration-300">
                      <div className="relative overflow-hidden h-40">
                        <img src={article.featured_image} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        <div className="ribbon">{article.category}</div>
                      </div>
                      <div className="p-4">
                        <h4 className="font-bold text-blue-900 text-sm mb-2 leading-tight line-clamp-2 group-hover:text-blue-700">{article.title}</h4>
                        <p className="text-gray-500 text-xs leading-relaxed line-clamp-2 mb-3">{article.content}</p>
                        <div className="flex items-center justify-between text-xs text-gray-400">
                          <span>By {article.author}</span>
                          <span>{format(new Date(article.created_at), 'MMM d')}</span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
                <Link to="/articles" className="mt-4 flex items-center justify-center gap-2 border-2 border-blue-100 hover:border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-900 py-3 rounded-xl text-sm font-semibold transition-all duration-200">
                  View All Articles <FaArrowRight size={12} />
                </Link>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-950 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-1/4 w-72 h-72 bg-yellow-400 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-72 h-72 bg-white rounded-full blur-3xl" />
        </div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <Reveal>
            <div className="w-20 h-20 bg-white rounded-full mx-auto mb-6 p-2 shadow-2xl">
              <img src="/logo.png" alt="School Logo" className="w-full h-full object-contain"
                onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              Join Our School Community
            </h2>
            <p className="text-blue-200 text-lg mb-8 max-w-2xl mx-auto">
              Be part of a community committed to academic excellence, character development, and the future of Uganda.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/contact" className="btn-secondary text-base px-8 py-4">Get in Touch <FaArrowRight /></Link>
              <Link to="/online-learning" className="bg-white/20 border border-white/30 text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/30 transition-all duration-300 flex items-center gap-2">
                Online Learning <FaArrowRight />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* QUICK LINKS */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h3 className="text-center text-lg font-bold text-blue-900 mb-6">Quick Links</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {[
              { to: '/about', label: 'About Us' },
              { to: '/gallery', label: 'Photo Gallery' },
              { to: '/articles', label: 'School Articles' },
              { to: '/online-learning', label: 'Online Learning' },
              { to: '/contact', label: 'Contact School' },
            ].map((link) => (
              <Link key={link.to} to={link.to}
                className="bg-white border border-gray-200 text-blue-900 px-5 py-2 rounded-full text-sm font-medium hover:bg-blue-900 hover:text-white hover:border-blue-900 transition-all duration-300 shadow-sm">
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
