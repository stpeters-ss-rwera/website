import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaLock, FaEnvelope, FaEye, FaEyeSlash } from 'react-icons/fa';
import { supabase } from '../../lib/supabase';
import { SCHOOL_INFO } from '../../lib/constants';
import toast from 'react-hot-toast';

const AdminLogin: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isReset, setIsReset] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) { toast.error('Please enter email and password.'); return; }
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        // Fallback demo login for development (when Supabase is not configured)
        if (email === 'admin@stpeters.rwera' && password === 'Admin@2024!') {
          localStorage.setItem('admin_demo_auth', 'true');
          toast.success('Welcome to the Admin Dashboard!');
          navigate('/admin/dashboard');
        } else {
          toast.error(error.message || 'Invalid credentials. Please try again.');
        }
      } else {
        toast.success('Login successful!');
        navigate('/admin/dashboard');
      }
    } catch {
      toast.error('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) { toast.error('Please enter your email address.'); return; }
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/admin/reset-password`,
      });
      if (error) throw error;
      toast.success('Password reset email sent! Check your inbox.');
      setIsReset(false);
    } catch {
      toast.error('Failed to send reset email. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-white rounded-full mx-auto mb-4 p-2 shadow-2xl">
            <img src="/logo.png" alt="School Logo" className="w-full h-full object-contain"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          </div>
          <h1 className="text-2xl font-bold text-white" style={{ fontFamily: 'Playfair Display, serif' }}>Admin Dashboard</h1>
          <p className="text-blue-300 text-sm mt-1">{SCHOOL_INFO.shortName}</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          {!isReset ? (
            <>
              <h2 className="text-xl font-bold text-blue-900 mb-6">Sign In</h2>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Email Address</label>
                  <div className="relative">
                    <FaEnvelope className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="admin@example.com"
                      className="form-input pl-10"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Password</label>
                  <div className="relative">
                    <FaLock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
                    <input
                      type={showPass ? 'text' : 'password'}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="form-input pl-10 pr-10"
                      required
                    />
                    <button type="button" onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {showPass ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
                    </button>
                  </div>
                </div>
                <button type="submit" disabled={loading}
                  className="w-full bg-blue-900 hover:bg-blue-800 text-white py-3 rounded-lg font-bold transition-all duration-300 disabled:opacity-60 flex items-center justify-center gap-2">
                  {loading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : null}
                  {loading ? 'Signing in...' : 'Sign In'}
                </button>
              </form>
              <button onClick={() => setIsReset(true)} className="w-full mt-3 text-sm text-blue-600 hover:text-blue-800 transition-colors">
                Forgot password?
              </button>

              <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-200">
                <p className="text-xs text-blue-800 font-semibold mb-1">📋 Demo Access</p>
                <p className="text-xs text-blue-700">Email: <code>admin@stpeters.rwera</code></p>
                <p className="text-xs text-blue-700">Password: <code>Admin@2024!</code></p>
                <p className="text-xs text-gray-500 mt-1">Replace with your Supabase admin credentials in production.</p>
              </div>
            </>
          ) : (
            <>
              <h2 className="text-xl font-bold text-blue-900 mb-2">Reset Password</h2>
              <p className="text-gray-500 text-sm mb-6">Enter your email to receive a password reset link.</p>
              <form onSubmit={handlePasswordReset} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Email Address</label>
                  <div className="relative">
                    <FaEnvelope className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
                    <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                      placeholder="admin@example.com" className="form-input pl-10" required />
                  </div>
                </div>
                <button type="submit" disabled={loading}
                  className="w-full bg-blue-900 text-white py-3 rounded-lg font-bold hover:bg-blue-800 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
                  {loading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : null}
                  Send Reset Link
                </button>
              </form>
              <button onClick={() => setIsReset(false)} className="w-full mt-3 text-sm text-blue-600 hover:text-blue-800 transition-colors">
                ← Back to Sign In
              </button>
            </>
          )}
        </div>

        <p className="text-center text-blue-400 text-xs mt-6">
          Secure Admin Access • {SCHOOL_INFO.name}
        </p>
      </div>
    </div>
  );
};

export default AdminLogin;
