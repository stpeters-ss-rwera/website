import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useInView } from 'react-intersection-observer';
import { FaSearch, FaCalendarAlt, FaUser, FaTag, FaArrowLeft, FaArrowRight } from 'react-icons/fa';
import { SAMPLE_ARTICLES } from '../lib/constants';
import { format } from 'date-fns';

const Reveal: React.FC<{ children: React.ReactNode; delay?: number }> = ({ children, delay = 0 }) => {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });
  return (
    <div ref={ref} className="transition-all duration-700"
      style={{ transitionDelay: `${delay}ms`, opacity: inView ? 1 : 0, transform: inView ? 'translateY(0)' : 'translateY(20px)' }}>
      {children}
    </div>
  );
};

const PageHero: React.FC<{ title: string; subtitle: string }> = ({ title, subtitle }) => (
  <div className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-950 py-16 md:py-20 relative overflow-hidden">
    <div className="absolute inset-0 opacity-10">
      <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400 rounded-full -translate-y-1/2 translate-x-1/3" />
    </div>
    <div className="container mx-auto px-4 text-center relative z-10">
      <div className="inline-block bg-yellow-400 text-blue-900 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">{subtitle}</div>
      <h1 className="text-3xl md:text-5xl font-bold text-white" style={{ fontFamily: 'Playfair Display, serif' }}>{title}</h1>
    </div>
  </div>
);

// Article Detail Component
export const ArticleDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const article = SAMPLE_ARTICLES.find(a => a.id === id);

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">📄</div>
          <h2 className="text-2xl font-bold text-gray-400 mb-4">Article Not Found</h2>
          <Link to="/articles" className="btn-primary">Back to Articles</Link>
        </div>
      </div>
    );
  }

  const related = SAMPLE_ARTICLES.filter(a => a.id !== id && a.category === article.category).slice(0, 2);

  return (
    <div>
      <div className="bg-gradient-to-br from-blue-900 to-blue-950 py-16">
        <div className="container mx-auto px-4">
          <Link to="/articles" className="inline-flex items-center gap-2 text-blue-200 hover:text-white mb-6 text-sm font-medium transition-colors">
            <FaArrowLeft size={12} /> Back to Articles
          </Link>
          <div className="max-w-3xl">
            <span className="inline-block bg-yellow-400 text-blue-900 text-xs font-bold px-3 py-1 rounded-full mb-4">{article.category}</span>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>{article.title}</h1>
            <div className="flex flex-wrap items-center gap-4 text-blue-200 text-sm">
              <span className="flex items-center gap-1.5"><FaUser size={12} /> {article.author}</span>
              <span className="flex items-center gap-1.5"><FaCalendarAlt size={12} /> {format(new Date(article.created_at), 'MMMM d, yyyy')}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2">
            {article.featured_image && (
              <img src={article.featured_image} alt={article.title} className="w-full h-72 object-cover rounded-2xl shadow-lg mb-8" />
            )}
            <div className="prose max-w-none">
              <p className="text-gray-700 leading-relaxed text-lg mb-4">{article.content}</p>
              <p className="text-gray-600 leading-relaxed mb-4">
                Education is the cornerstone of national development. At St. Peter's Secondary School – Rwera, we are committed to providing comprehensive learning experiences that prepare students not just for examinations, but for life itself. Our curriculum integrates academic rigor with practical skills, character formation, and community awareness.
              </p>
              <p className="text-gray-600 leading-relaxed mb-4">
                The Uganda National Curriculum promotes holistic development, and our teachers are trained to deliver content in engaging, student-centered ways. We believe every child has unique gifts, and our role as educators is to identify, nurture, and celebrate those gifts.
              </p>
              <p className="text-gray-600 leading-relaxed">
                We encourage parents and guardians to remain actively involved in their children's education. Research consistently shows that parental involvement significantly improves academic outcomes. Together, we can ensure that every student at St. Peter's SS Rwera reaches their full potential.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 mt-6">
              {article.tags.map(tag => (
                <span key={tag} className="flex items-center gap-1 bg-blue-100 text-blue-800 text-xs font-semibold px-3 py-1 rounded-full">
                  <FaTag size={9} /> {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-2xl p-6 mb-6">
              <h3 className="font-bold text-blue-900 mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>About the Author</h3>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-900 rounded-full flex items-center justify-center">
                  <FaUser className="text-white" />
                </div>
                <div>
                  <p className="font-semibold text-blue-900 text-sm">{article.author}</p>
                  <p className="text-gray-500 text-xs">St. Peter's SS Rwera</p>
                </div>
              </div>
            </div>

            {related.length > 0 && (
              <div>
                <h3 className="font-bold text-blue-900 mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>Related Articles</h3>
                <div className="space-y-4">
                  {related.map(r => (
                    <Link key={r.id} to={`/articles/${r.id}`} className="flex gap-3 bg-white rounded-xl p-3 shadow-sm hover:shadow-md transition-all duration-200 group">
                      <img src={r.featured_image} alt={r.title} className="w-16 h-16 object-cover rounded-lg flex-shrink-0" />
                      <div>
                        <p className="text-blue-900 text-sm font-semibold leading-tight line-clamp-2 group-hover:text-blue-700">{r.title}</p>
                        <p className="text-gray-400 text-xs mt-1">{format(new Date(r.created_at), 'MMM d')}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Articles List Component
const Articles: React.FC = () => {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const perPage = 6;

  const categories = ['All', ...Array.from(new Set(SAMPLE_ARTICLES.map(a => a.category)))];

  const filtered = SAMPLE_ARTICLES.filter(a => {
    const matchCat = activeCategory === 'All' || a.category === activeCategory;
    const matchSearch = a.title.toLowerCase().includes(search.toLowerCase()) ||
      a.author.toLowerCase().includes(search.toLowerCase()) ||
      a.tags.some(t => t.toLowerCase().includes(search.toLowerCase()));
    return matchCat && matchSearch;
  });

  const totalPages = Math.ceil(filtered.length / perPage);
  const paginated = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

  const featured = SAMPLE_ARTICLES[0];

  return (
    <div>
      <PageHero title="School Articles" subtitle="Learning Resources" />

      {/* Featured Article */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <Reveal>
            <Link to={`/articles/${featured.id}`} className="group block bg-gradient-to-br from-blue-900 to-blue-800 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300">
              <div className="grid md:grid-cols-2">
                <div className="relative h-56 md:h-full overflow-hidden">
                  <img src={featured.featured_image} alt={featured.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-blue-900/30" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-yellow-400 text-blue-900 text-xs font-bold px-3 py-1 rounded-full">⭐ Featured</span>
                  </div>
                </div>
                <div className="p-8 flex flex-col justify-center">
                  <span className="inline-block bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full mb-3 w-fit">{featured.category}</span>
                  <h2 className="text-2xl md:text-3xl font-bold text-white mb-3 leading-tight group-hover:text-yellow-300 transition-colors" style={{ fontFamily: 'Playfair Display, serif' }}>
                    {featured.title}
                  </h2>
                  <p className="text-blue-200 text-sm leading-relaxed mb-4 line-clamp-3">{featured.content}</p>
                  <div className="flex items-center gap-4 text-blue-300 text-xs mb-4">
                    <span className="flex items-center gap-1.5"><FaUser size={10} /> {featured.author}</span>
                    <span className="flex items-center gap-1.5"><FaCalendarAlt size={10} /> {format(new Date(featured.created_at), 'MMM d, yyyy')}</span>
                  </div>
                  <div className="flex items-center gap-2 text-yellow-400 font-semibold text-sm">
                    Read Article <FaArrowRight size={12} />
                  </div>
                </div>
              </div>
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-8">
            <div className="relative w-full md:w-80">
              <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input
                type="text"
                placeholder="Search articles..."
                value={search}
                onChange={e => { setSearch(e.target.value); setCurrentPage(1); }}
                className="form-input pl-9 text-sm"
              />
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => { setActiveCategory(cat); setCurrentPage(1); }}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-300 ${activeCategory === cat ? 'bg-blue-900 text-white shadow-md' : 'bg-white text-gray-600 hover:bg-gray-200 border border-gray-200'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {paginated.map((article, i) => (
              <Reveal key={article.id} delay={i * 80}>
                <Link to={`/articles/${article.id}`} className="card group h-full flex flex-col hover:-translate-y-1 transition-all duration-300">
                  <div className="relative h-48 overflow-hidden">
                    <img src={article.featured_image} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute top-3 left-3">
                      <span className="bg-white text-blue-900 text-xs font-bold px-2 py-1 rounded-full shadow">{article.category}</span>
                    </div>
                  </div>
                  <div className="p-5 flex flex-col flex-1">
                    <h3 className="font-bold text-blue-900 text-base mb-2 leading-tight line-clamp-2 group-hover:text-blue-700 transition-colors" style={{ fontFamily: 'Playfair Display, serif' }}>
                      {article.title}
                    </h3>
                    <p className="text-gray-500 text-sm leading-relaxed line-clamp-3 mb-3 flex-1">{article.content}</p>
                    <div className="flex flex-wrap gap-1 mb-3">
                      {article.tags.slice(0, 3).map(tag => (
                        <span key={tag} className="bg-blue-50 text-blue-700 text-xs px-2 py-0.5 rounded-full">{tag}</span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-400 pt-3 border-t border-gray-100">
                      <span className="flex items-center gap-1"><FaUser size={9} /> {article.author}</span>
                      <span className="flex items-center gap-1"><FaCalendarAlt size={9} /> {format(new Date(article.created_at), 'MMM d, yyyy')}</span>
                    </div>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">📰</div>
              <h3 className="text-xl font-bold text-gray-400 mb-2">No Articles Found</h3>
              <p className="text-gray-400">Try a different search or category.</p>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center gap-2 mt-10">
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}
                className="w-9 h-9 flex items-center justify-center rounded-lg border border-gray-200 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                <FaArrowLeft size={12} />
              </button>
              {Array.from({ length: totalPages }, (_, i) => (
                <button key={i} onClick={() => setCurrentPage(i + 1)}
                  className={`w-9 h-9 rounded-lg text-sm font-semibold transition-all ${currentPage === i + 1 ? 'bg-blue-900 text-white' : 'border border-gray-200 hover:bg-gray-100'}`}>
                  {i + 1}
                </button>
              ))}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}
                className="w-9 h-9 flex items-center justify-center rounded-lg border border-gray-200 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                <FaArrowRight size={12} />
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Articles;
