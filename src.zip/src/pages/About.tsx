import React, { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { FaEye, FaBullseye, FaHeart, FaGraduationCap, FaUsers, FaChurch, FaFlask, FaBook, FaAward, FaStar } from 'react-icons/fa';
import { SAMPLE_TEACHERS, SAMPLE_PREFECTS, SCHOOL_INFO } from '../lib/constants';

const Reveal: React.FC<{ children: React.ReactNode; className?: string; delay?: number }> = ({ children, className = '', delay = 0 }) => {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });
  return (
    <div ref={ref} className={`transition-all duration-700 ${className}`}
      style={{ transitionDelay: `${delay}ms`, opacity: inView ? 1 : 0, transform: inView ? 'translateY(0)' : 'translateY(30px)' }}>
      {children}
    </div>
  );
};

const PageHero: React.FC<{ title: string; subtitle: string }> = ({ title, subtitle }) => (
  <div className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-950 py-16 md:py-20 relative overflow-hidden">
    <div className="absolute inset-0 opacity-10">
      <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400 rounded-full -translate-y-1/2 translate-x-1/3" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-white rounded-full translate-y-1/2 -translate-x-1/3" />
    </div>
    <div className="container mx-auto px-4 text-center relative z-10">
      <div className="inline-block bg-yellow-400 text-blue-900 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">
        {subtitle}
      </div>
      <h1 className="text-3xl md:text-5xl font-bold text-white" style={{ fontFamily: 'Playfair Display, serif' }}>{title}</h1>
    </div>
  </div>
);

const About: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'teachers' | 'prefects'>('teachers');

  const values = [
    { icon: FaHeart, title: 'Integrity', desc: 'We uphold the highest standards of honesty, transparency, and ethical conduct.' },
    { icon: FaGraduationCap, title: 'Excellence', desc: 'We strive for the highest quality in all academic and co-curricular endeavors.' },
    { icon: FaUsers, title: 'Community', desc: 'We foster a supportive, inclusive learning community for all stakeholders.' },
    { icon: FaChurch, title: 'Faith', desc: 'Guided by Christian values and principles in all aspects of school life.' },
    { icon: FaBook, title: 'Discipline', desc: 'We maintain high standards of conduct, responsibility, and self-regulation.' },
    { icon: FaAward, title: 'Leadership', desc: 'We develop future leaders through mentorship, responsibility, and service.' },
  ];

  const programs = [
    { icon: FaBook, title: 'O-Level (UCE)', desc: 'Four-year Uganda Certificate of Education program offering diverse subject combinations.' },
    { icon: FaFlask, title: 'Sciences', desc: 'Physics, Chemistry, Biology, and Mathematics for science-oriented students.' },
    { icon: FaBook, title: 'Humanities', desc: 'History, Geography, Economics, Literature, and Social Sciences.' },
    { icon: FaUsers, title: 'Languages', desc: 'English Language, Luganda, and other communication skills programs.' },
  ];

  const facilities = [
    { emoji: '🏫', title: 'Modern Classrooms', desc: 'Well-ventilated, spacious classrooms with proper seating and lighting.' },
    { emoji: '🔬', title: 'Science Labs', desc: 'Biology, Chemistry, and Physics laboratories with essential equipment.' },
    { emoji: '📚', title: 'Library', desc: 'A well-stocked library with academic books and reference materials.' },
    { emoji: '⚽', title: 'Sports Grounds', desc: 'Spacious grounds for football, netball, athletics, and other sports.' },
    { emoji: '🏠', title: 'Dormitories', desc: 'Comfortable boarding facilities for resident students.' },
    { emoji: '🍽️', title: 'Dining Hall', desc: 'Spacious dining facilities providing nutritious meals for students.' },
  ];

  const achievements = [
    { year: '2023', title: 'Best UCE Performance', desc: 'Top 10 school in Ntungamo District by UCE results.' },
    { year: '2022', title: 'Sports Champions', desc: 'District champions in football and netball competitions.' },
    { year: '2021', title: 'Community Award', desc: 'Recognized for excellence in community service programs.' },
    { year: '2020', title: 'Academic Excellence', desc: 'Highest First Grade pass rate in the sub-county.' },
  ];

  return (
    <div>
      <PageHero title="About Our School" subtitle="Our Story" />

      {/* HISTORY */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <Reveal>
              <span className="inline-block bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">Our History</span>
              <h2 className="section-title">A Legacy of Academic Excellence</h2>
              <p className="text-gray-600 leading-relaxed mb-4">
                St. Peter's Secondary School – Rwera was established in 2019 with a vision to provide quality secondary education to the youth of Rwera, Kakukuru-Rwenanura Town Council, and the surrounding communities of Ruhaama, Ntungamo District.
              </p>
              <p className="text-gray-600 leading-relaxed mb-4">
                Founded on strong Christian values and a commitment to academic excellence, the school has steadily grown to become a respected institution of learning in Western Uganda. Our motto, <strong className="text-blue-900">"Invest in Education"</strong>, reflects our deep belief that education is the greatest investment any individual, family, or community can make.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Today, St. Peter's SS Rwera serves hundreds of students from diverse backgrounds, providing them with a comprehensive education that prepares them for national examinations, higher education, and productive citizenship in Uganda and beyond.
              </p>
            </Reveal>

            <Reveal delay={200}>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-900 text-white rounded-2xl p-6 text-center">
                  <div className="text-4xl font-bold text-yellow-400 mb-2">2019</div>
                  <div className="text-sm font-medium text-blue-200">Year Founded</div>
                </div>
                <div className="bg-yellow-400 text-blue-900 rounded-2xl p-6 text-center">
                  <div className="text-4xl font-bold mb-2">800+</div>
                  <div className="text-sm font-bold">Students</div>
                </div>
                <div className="bg-green-700 text-white rounded-2xl p-6 text-center">
                  <div className="text-4xl font-bold mb-2">45+</div>
                  <div className="text-sm font-medium text-green-200">Teachers</div>
                </div>
                <div className="bg-gray-100 text-blue-900 rounded-2xl p-6 text-center">
                  <div className="text-4xl font-bold mb-2">95%</div>
                  <div className="text-sm font-bold">Pass Rate</div>
                </div>
                <div className="col-span-2 bg-gradient-to-r from-blue-900 to-blue-700 text-white rounded-2xl p-6 text-center">
                  <FaStar className="text-yellow-400 mx-auto mb-2" size={28} />
                  <div className="font-bold">Ntungamo District, Uganda</div>
                  <div className="text-blue-200 text-sm mt-1">Serving Rwera & Surrounding Communities</div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* VISION MISSION */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <Reveal className="text-center mb-12">
            <h2 className="section-title">Vision, Mission & Values</h2>
          </Reveal>
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {[
              {
                icon: FaEye, title: 'Our Vision', color: 'bg-blue-900',
                content: 'To be a leading secondary school in Uganda that produces academically excellent, morally upright, and socially responsible citizens who contribute meaningfully to the development of Uganda and the world.'
              },
              {
                icon: FaBullseye, title: 'Our Mission', color: 'bg-yellow-500',
                content: 'To provide holistic, quality secondary education in a Christian environment that fosters academic excellence, character development, and lifelong learning, thereby equipping students with knowledge, skills, and values for a productive life.'
              },
              {
                icon: FaHeart, title: 'Our Motto', color: 'bg-green-700',
                content: '"INVEST IN EDUCATION" — We believe education is the most powerful investment for individual transformation and national development. Every student deserves access to quality education that unlocks their full potential.'
              },
            ].map((item, i) => (
              <Reveal key={i} delay={i * 150}>
                <div className="bg-white rounded-2xl shadow-md overflow-hidden h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className={`${item.color} p-6`}>
                    <item.icon size={32} className="text-white mb-2" />
                    <h3 className="text-white text-xl font-bold" style={{ fontFamily: 'Playfair Display, serif' }}>{item.title}</h3>
                  </div>
                  <div className="p-6">
                    <p className="text-gray-600 leading-relaxed text-sm">{item.content}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          {/* Core Values */}
          <Reveal className="text-center mb-8">
            <h3 className="text-2xl font-bold text-blue-900" style={{ fontFamily: 'Playfair Display, serif' }}>Core Values</h3>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {values.map((v, i) => (
              <Reveal key={i} delay={i * 100}>
                <div className="bg-white rounded-xl p-5 shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1 flex gap-4 items-start">
                  <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <v.icon className="text-blue-900" size={18} />
                  </div>
                  <div>
                    <h4 className="font-bold text-blue-900 text-sm mb-1">{v.title}</h4>
                    <p className="text-gray-500 text-xs leading-relaxed">{v.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ACADEMIC PROGRAMS */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <Reveal className="text-center mb-12">
            <span className="inline-block bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-3">What We Offer</span>
            <h2 className="section-title">Academic Programs</h2>
            <p className="section-subtitle">Comprehensive curriculum designed to prepare students for national examinations and beyond</p>
          </Reveal>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {programs.map((p, i) => (
              <Reveal key={i} delay={i * 100}>
                <div className="bg-gradient-to-br from-blue-900 to-blue-800 text-white rounded-2xl p-6 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                  <p.icon size={32} className="text-yellow-400 mb-4" />
                  <h3 className="font-bold text-lg mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>{p.title}</h3>
                  <p className="text-blue-200 text-sm leading-relaxed">{p.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* TEACHERS & PREFECTS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <Reveal className="text-center mb-8">
            <h2 className="section-title">Our People</h2>
            <p className="section-subtitle">Meet the dedicated educators and student leaders of St. Peter's SS Rwera</p>
          </Reveal>

          <div className="flex justify-center gap-2 mb-10">
            <button
              onClick={() => setActiveTab('teachers')}
              className={`px-6 py-2.5 rounded-full font-semibold text-sm transition-all duration-300 ${activeTab === 'teachers' ? 'bg-blue-900 text-white shadow-md' : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'}`}
            >
              Our Teachers
            </button>
            <button
              onClick={() => setActiveTab('prefects')}
              className={`px-6 py-2.5 rounded-full font-semibold text-sm transition-all duration-300 ${activeTab === 'prefects' ? 'bg-blue-900 text-white shadow-md' : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'}`}
            >
              Prefectorial Body
            </button>
          </div>

          {activeTab === 'teachers' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
              {SAMPLE_TEACHERS.map((teacher, i) => (
                <Reveal key={teacher.id} delay={i * 100}>
                  <div className="teacher-card card overflow-hidden group">
                    <div className="relative h-48 bg-gradient-to-br from-blue-100 to-blue-200 overflow-hidden">
                      {teacher.photo_url ? (
                        <img src={teacher.photo_url} alt={teacher.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <div className="w-24 h-24 bg-blue-900 rounded-full flex items-center justify-center shadow-lg">
                            <FaUsers size={40} className="text-white" />
                          </div>
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </div>
                    <div className="p-5">
                      <h3 className="font-bold text-blue-900 text-base" style={{ fontFamily: 'Playfair Display, serif' }}>{teacher.name}</h3>
                      <p className="text-yellow-600 text-sm font-semibold mb-2">{teacher.position}</p>
                      <p className="text-gray-500 text-xs leading-relaxed">{teacher.bio}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          )}

          {activeTab === 'prefects' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {SAMPLE_PREFECTS.map((prefect, i) => (
                <Reveal key={prefect.id} delay={i * 80}>
                  <div className="teacher-card card overflow-hidden group text-center">
                    <div className="relative h-36 bg-gradient-to-br from-yellow-100 to-yellow-200 overflow-hidden">
                      {prefect.photo_url ? (
                        <img src={prefect.photo_url} alt={prefect.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <div className="w-16 h-16 bg-blue-900 rounded-full flex items-center justify-center shadow-md">
                            <FaUsers size={28} className="text-white" />
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="p-3">
                      <h4 className="font-bold text-blue-900 text-xs leading-tight">{prefect.name}</h4>
                      <p className="text-yellow-600 text-xs font-semibold mt-1">{prefect.position}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* FACILITIES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <Reveal className="text-center mb-12">
            <span className="inline-block bg-green-100 text-green-800 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-3">Our Campus</span>
            <h2 className="section-title">School Facilities</h2>
            <p className="section-subtitle">Modern facilities designed to support holistic student development</p>
          </Reveal>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {facilities.map((f, i) => (
              <Reveal key={i} delay={i * 100}>
                <div className="flex gap-4 p-5 bg-gray-50 rounded-2xl hover:bg-blue-50 hover:shadow-md transition-all duration-300 group">
                  <div className="text-4xl">{f.emoji}</div>
                  <div>
                    <h4 className="font-bold text-blue-900 mb-1 group-hover:text-blue-700">{f.title}</h4>
                    <p className="text-gray-600 text-sm leading-relaxed">{f.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ACHIEVEMENTS */}
      <section className="py-16 bg-blue-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-400 rounded-full -translate-y-1/2 translate-x-1/2" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <Reveal className="text-center mb-12">
            <span className="inline-block bg-yellow-400 text-blue-900 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-3">Our Achievements</span>
            <h2 className="text-3xl md:text-4xl font-bold text-white" style={{ fontFamily: 'Playfair Display, serif' }}>School Milestones</h2>
          </Reveal>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {achievements.map((a, i) => (
              <Reveal key={i} delay={i * 100}>
                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 hover:bg-white/20 transition-all duration-300">
                  <div className="text-yellow-400 text-3xl font-bold mb-2">{a.year}</div>
                  <div className="text-white font-bold text-lg mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>{a.title}</div>
                  <p className="text-blue-200 text-sm leading-relaxed">{a.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* LEADERSHIP */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <Reveal className="text-center mb-10">
            <h2 className="section-title">School Leadership</h2>
          </Reveal>
          <div className="max-w-2xl mx-auto">
            <Reveal>
              <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-900 to-blue-700 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
                  <FaUsers size={36} className="text-white" />
                </div>
                <h3 className="text-2xl font-bold text-blue-900 mb-1" style={{ fontFamily: 'Playfair Display, serif' }}>Head Teacher</h3>
                <p className="text-yellow-600 font-semibold mb-4">School Leadership</p>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  Our Head Teacher provides visionary leadership, guiding St. Peter's SS Rwera toward academic excellence and holistic student development in alignment with our school motto and Uganda's national education goals.
                </p>
                <a href={`tel:${SCHOOL_INFO.headTeacherPhone}`}
                  className="inline-flex items-center gap-2 bg-blue-900 text-white px-6 py-2.5 rounded-lg font-semibold hover:bg-blue-800 transition-colors text-sm">
                  📞 {SCHOOL_INFO.headTeacherPhone}
                </a>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
