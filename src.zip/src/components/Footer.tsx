import React from 'react';
import { Link } from 'react-router-dom';
import { FaPhone, FaEnvelope, FaMapMarkerAlt, FaWhatsapp, FaFacebook, FaTwitter, FaYoutube } from 'react-icons/fa';
import { SCHOOL_INFO } from '../lib/constants';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-blue-950 text-gray-300">
      {/* Main footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* School Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 bg-white rounded-lg p-1.5 flex-shrink-0">
                <img
                  src="/logo.png"
                  alt="St. Peter's SS Rwera"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    const t = e.target as HTMLImageElement;
                    t.style.display = 'none';
                  }}
                />
              </div>
              <div>
                <h3 className="text-white font-bold text-sm leading-tight">ST. PETER'S SEC. SCHOOL</h3>
                <p className="text-yellow-400 text-xs font-medium">– RWERA –</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed mb-4">
              Providing quality secondary education in Ntungamo District, Uganda. Our motto: <em className="text-yellow-400 font-semibold">"{SCHOOL_INFO.motto}"</em>
            </p>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-8 h-8 bg-blue-800 hover:bg-blue-600 rounded-full flex items-center justify-center transition-colors">
                <FaFacebook size={14} />
              </a>
              <a href="#" className="w-8 h-8 bg-blue-800 hover:bg-sky-500 rounded-full flex items-center justify-center transition-colors">
                <FaTwitter size={14} />
              </a>
              <a href={SCHOOL_INFO.whatsappGroupLink} target="_blank" rel="noopener noreferrer" className="w-8 h-8 bg-blue-800 hover:bg-green-600 rounded-full flex items-center justify-center transition-colors">
                <FaWhatsapp size={14} />
              </a>
              <a href="#" className="w-8 h-8 bg-blue-800 hover:bg-red-600 rounded-full flex items-center justify-center transition-colors">
                <FaYoutube size={14} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold text-sm uppercase tracking-wider mb-4 pb-2 border-b border-blue-800">Quick Links</h4>
            <ul className="space-y-2">
              {[
                { to: '/', label: 'Home' },
                { to: '/about', label: 'About Us' },
                { to: '/gallery', label: 'Gallery' },
                { to: '/articles', label: 'Articles' },
                { to: '/online-learning', label: 'Online Learning' },
                { to: '/contact', label: 'Contact Us' },
                { to: '/admin', label: 'Admin Dashboard' },
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="footer-link text-sm flex items-center gap-2">
                    <span className="text-yellow-400 text-xs">›</span>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-bold text-sm uppercase tracking-wider mb-4 pb-2 border-b border-blue-800">Contact Us</h4>
            <ul className="space-y-3">
              <li>
                <div className="flex items-start gap-2.5">
                  <FaMapMarkerAlt className="text-yellow-400 mt-1 flex-shrink-0" size={13} />
                  <span className="text-sm leading-relaxed">{SCHOOL_INFO.location}</span>
                </div>
              </li>
              <li>
                <a href={`tel:${SCHOOL_INFO.headTeacherPhone}`} className="flex items-center gap-2.5 hover:text-yellow-400 transition-colors text-sm">
                  <FaPhone className="text-yellow-400 flex-shrink-0" size={13} />
                  <span>{SCHOOL_INFO.headTeacherPhone} (Head Teacher)</span>
                </a>
              </li>
              <li>
                <a href={`mailto:${SCHOOL_INFO.email}`} className="flex items-center gap-2.5 hover:text-yellow-400 transition-colors text-sm">
                  <FaEnvelope className="text-yellow-400 flex-shrink-0" size={13} />
                  <span className="break-all">{SCHOOL_INFO.email}</span>
                </a>
              </li>
              <li>
                <a href={`https://wa.me/${SCHOOL_INFO.whatsappContact.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2.5 hover:text-green-400 transition-colors text-sm">
                  <FaWhatsapp className="text-green-400 flex-shrink-0" size={14} />
                  <span>{SCHOOL_INFO.whatsappContact} (WhatsApp)</span>
                </a>
              </li>
            </ul>
          </div>

          {/* WhatsApp Group & Newsletter */}
          <div>
            <h4 className="text-white font-bold text-sm uppercase tracking-wider mb-4 pb-2 border-b border-blue-800">Stay Connected</h4>
            <p className="text-sm mb-4 leading-relaxed">
              Join our community for the latest news, announcements, and school updates.
            </p>
            <a
              href={SCHOOL_INFO.whatsappGroupLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white px-4 py-3 rounded-lg text-sm font-semibold transition-all duration-200 text-center justify-center"
            >
              <FaWhatsapp size={16} />
              <span>Join Parents & Teachers Group</span>
            </a>
            <div className="mt-4 p-3 bg-blue-900/50 rounded-lg border border-blue-800">
              <p className="text-xs text-gray-400 leading-relaxed">
                <span className="text-yellow-400 font-semibold">School Hours:</span><br />
                Monday – Friday: 8:00 AM – 5:00 PM<br />
                Saturday: 8:00 AM – 1:00 PM
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-blue-900">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-2 text-xs text-gray-500">
            <p>
              © {currentYear} <span className="text-gray-400 font-medium">{SCHOOL_INFO.name}</span>. All rights reserved.
            </p>
            <p>
              Designed with ❤️ for quality education in Uganda
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
