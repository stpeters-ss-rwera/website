import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FaBars, FaTimes, FaPhone, FaEnvelope } from 'react-icons/fa';
import { SCHOOL_INFO } from '../lib/constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/about', label: 'About Us' },
    { to: '/gallery', label: 'Gallery' },
    { to: '/articles', label: 'Articles' },
    { to: '/online-learning', label: 'Online Learning' },
    { to: '/contact', label: 'Contact Us' },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <>
      {/* Top bar */}
      <div className="bg-blue-900 text-white text-xs py-2 hidden md:block">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-6">
            <a href={`tel:${SCHOOL_INFO.headTeacherPhone}`} className="flex items-center gap-1.5 hover:text-yellow-400 transition-colors">
              <FaPhone size={10} />
              <span>{SCHOOL_INFO.headTeacherPhone}</span>
            </a>
            <a href={`mailto:${SCHOOL_INFO.email}`} className="flex items-center gap-1.5 hover:text-yellow-400 transition-colors">
              <FaEnvelope size={10} />
              <span>{SCHOOL_INFO.email}</span>
            </a>
          </div>
          <div className="text-yellow-400 font-medium italic text-xs">
            "{SCHOOL_INFO.motto}"
          </div>
        </div>
      </div>

      {/* Main nav */}
      <nav className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-lg py-2' : 'bg-white/95 backdrop-blur-sm py-3'}`}>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-12 h-12 flex-shrink-0">
                <img
                  src="/logo.png"
                  alt="St. Peter's SS Rwera Logo"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                />
              </div>
              <div>
                <div className="text-blue-900 font-bold text-sm leading-tight">ST. PETER'S SEC. SCHOOL</div>
                <div className="text-yellow-500 text-xs font-semibold leading-tight">– RWERA –</div>
                <div className="text-gray-500 text-xs italic">{SCHOOL_INFO.motto}</div>
              </div>
            </Link>

            {/* Desktop nav links */}
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`nav-link px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                    isActive(link.to)
                      ? 'text-blue-900 bg-blue-50 active'
                      : 'text-gray-700 hover:text-blue-900 hover:bg-gray-50'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                to="/admin"
                className="ml-2 bg-yellow-400 text-blue-900 px-4 py-2 rounded-lg text-sm font-bold hover:bg-yellow-300 transition-all duration-200"
              >
                Admin
              </Link>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="lg:hidden p-2 rounded-lg text-blue-900 hover:bg-blue-50 transition-colors"
              aria-label="Toggle menu"
            >
              {isOpen ? <FaTimes size={22} /> : <FaBars size={22} />}
            </button>
          </div>

          {/* Mobile menu */}
          <div className={`mobile-menu lg:hidden ${isOpen ? 'open' : ''}`}>
            <div className="py-3 space-y-1 border-t border-gray-100 mt-3">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`block px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive(link.to)
                      ? 'text-blue-900 bg-blue-50 font-semibold'
                      : 'text-gray-700 hover:text-blue-900 hover:bg-gray-50'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                to="/admin"
                className="block mt-2 bg-blue-900 text-white px-4 py-3 rounded-lg text-sm font-bold text-center hover:bg-blue-800 transition-colors"
              >
                Admin Dashboard
              </Link>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
